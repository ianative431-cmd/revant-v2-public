self.addEventListener("push", (event) => {
  let data = {};
  try { data = event.data ? event.data.json() : {}; } catch {}
  event.waitUntil(self.registration.showNotification(data.title || "Revant", { body: data.body || "Nouvelle notification", icon: "/revant-mark.svg", badge: "/revant-mark.svg", data: data.data || {} }));
});
self.addEventListener("notificationclick", (event) => {
  event.notification.close();
  const target = event.notification.data?.url || "/driver";
  event.waitUntil(clients.matchAll({ type:"window", includeUncontrolled:true }).then((list) => {
    for (const client of list) if ("focus" in client) { client.navigate(target); return client.focus(); }
    return clients.openWindow(target);
  }));
});
