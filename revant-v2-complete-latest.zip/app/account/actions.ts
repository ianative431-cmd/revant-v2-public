'use server';
import { createClient } from '@/lib/supabase/server';
import { redirect } from 'next/navigation';

export async function updateProfile(formData: FormData) {
  const displayName = String(formData.get('display_name') ?? '').trim();
  const firstName = String(formData.get('first_name') ?? '').trim() || null;
  const lastName = String(formData.get('last_name') ?? '').trim() || null;
  const phone = String(formData.get('phone') ?? '').trim() || null;
  const city = String(formData.get('city') ?? '').trim() || null;
  if (!displayName) redirect('/account?error=profile');

  const supabase = await createClient();
  const { data: claims } = await supabase.auth.getClaims();
  const userId = claims?.claims?.sub;
  if (!userId) redirect('/login');

  const { error } = await supabase.from('profiles').update({
    display_name: displayName,
    first_name: firstName,
    last_name: lastName,
    phone,
    city,
    updated_at: new Date().toISOString(),
  }).eq('id', userId);

  if (error) redirect('/account?error=profile');
  redirect('/account?saved=1');
}
