import Link from 'next/link';
import { requireUser } from '@/lib/auth/guards';
import { createClient } from '@/lib/supabase/server';
import { signOut } from '@/app/login/actions';
import { updateProfile } from './actions';

export default async function AccountPage({ searchParams }: { searchParams: Promise<{ saved?: string; error?: string }> }) {
  const user = await requireUser();
  const params = await searchParams;
  const supabase = await createClient();
  const { data: profile } = await supabase.from('profiles').select('display_name,first_name,last_name,phone,city,country_code,avatar_url').eq('id', user.id).maybeSingle();
  const { data: roles } = await supabase.from('user_roles').select('role').eq('user_id', user.id);
  const roleLabels = (roles ?? []).map((r: { role: string }) => r.role.replaceAll('_', ' '));

  return <main className="mx-auto min-h-screen max-w-4xl px-4 py-10">
    <div className="flex items-center justify-between gap-4">
      <Link href="/" className="text-sm font-semibold">← Revant</Link>
      <form action={signOut}><button className="rounded-full border border-[var(--border)] px-4 py-2 text-sm font-semibold">Se déconnecter</button></form>
    </div>
    <section className="mt-8 revant-card p-7">
      <p className="text-sm font-semibold text-[var(--accent)]">Mon compte</p>
      <h1 className="mt-2 text-4xl font-black tracking-[-.04em]">Mon profil</h1>
      <p className="mt-2 text-sm text-[var(--muted)]">{user.email || 'Compte Revant'}{roleLabels.length ? ` · ${roleLabels.join(', ')}` : ''}</p>
      {params.saved && <p className="mt-5 rounded-2xl bg-[#edf5ee] p-3 text-sm">Profil enregistré.</p>}
      {params.error && <p className="mt-5 rounded-2xl bg-[#f9e8e5] p-3 text-sm">Impossible d’enregistrer le profil.</p>}
      <form action={updateProfile} className="mt-7 grid gap-4 md:grid-cols-2">
        <label className="text-sm font-semibold md:col-span-2">Nom affiché<input name="display_name" required defaultValue={profile?.display_name ?? ''} className="mt-2 w-full rounded-2xl border border-[var(--border)] bg-white p-3" /></label>
        <label className="text-sm font-semibold">Prénom<input name="first_name" defaultValue={profile?.first_name ?? ''} className="mt-2 w-full rounded-2xl border border-[var(--border)] bg-white p-3" /></label>
        <label className="text-sm font-semibold">Nom<input name="last_name" defaultValue={profile?.last_name ?? ''} className="mt-2 w-full rounded-2xl border border-[var(--border)] bg-white p-3" /></label>
        <label className="text-sm font-semibold">Téléphone<input name="phone" defaultValue={profile?.phone ?? ''} className="mt-2 w-full rounded-2xl border border-[var(--border)] bg-white p-3" /></label>
        <label className="text-sm font-semibold">Ville<input name="city" defaultValue={profile?.city ?? ''} className="mt-2 w-full rounded-2xl border border-[var(--border)] bg-white p-3" /></label>
        <div className="md:col-span-2"><button className="rounded-2xl bg-[var(--foreground)] px-5 py-3 font-semibold text-white">Enregistrer</button></div>
      </form>
    </section>
    <div className="mt-5 grid gap-4 md:grid-cols-3">
      <Link href="/orders" className="revant-card p-5 font-semibold">Mes commandes →</Link>
      <Link href="/sell" className="revant-card p-5 font-semibold">Vendre sur Revant →</Link>
      <Link href="/support" className="revant-card p-5 font-semibold">Assistance →</Link>
    </div>
  </main>;
}
