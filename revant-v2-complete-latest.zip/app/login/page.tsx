import Link from "next/link";
import { signInWithPassword } from "./actions";

export default async function LoginPage({searchParams}:{searchParams:Promise<{error?:string;check_email?:string}>}) {
  const params=await searchParams;
  return <main className="grid min-h-screen place-items-center p-4">
    <section className="revant-card w-full max-w-md p-7">
      <Link href="/" className="text-2xl font-black tracking-[-.04em]">REVANT</Link>
      <h1 className="mt-10 text-3xl font-bold">Connexion</h1>
      <p className="mt-2 text-sm text-[var(--muted)]">Accédez à votre compte Revant.</p>
      {params.check_email && <p className="mt-4 rounded-2xl bg-[#edf5ee] p-3 text-sm">Compte créé. Vérifiez votre e-mail pour confirmer votre adresse avant de vous connecter.</p>}
      {params.error && <p className="mt-4 rounded-2xl bg-[#f9e8e5] p-3 text-sm">Identifiants invalides ou informations manquantes.</p>}
      <form action={signInWithPassword} className="mt-7 space-y-4">
        <label className="block text-sm font-semibold">E-mail<input name="email" type="email" required className="mt-2 w-full rounded-2xl border border-[var(--border)] bg-white p-3 outline-none focus:ring-2 focus:ring-[var(--accent-soft)]"/></label>
        <label className="block text-sm font-semibold">Mot de passe<input name="password" type="password" required className="mt-2 w-full rounded-2xl border border-[var(--border)] bg-white p-3 outline-none focus:ring-2 focus:ring-[var(--accent-soft)]"/></label>
        <button className="w-full rounded-2xl bg-[var(--foreground)] p-3 font-semibold text-white transition hover:opacity-90">Se connecter</button>
      </form>
      <p className="mt-6 text-center text-sm text-[var(--muted)]">Pas encore de compte ? <Link className="font-semibold text-[var(--accent)]" href="/signup">Créer un compte</Link></p>
    </section>
  </main>;
}
