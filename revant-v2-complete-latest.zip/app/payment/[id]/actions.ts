'use server';
import { createClient } from '@/lib/supabase/server';
import { redirect } from 'next/navigation';

export async function createPaymentIntent(formData: FormData) {
  const orderId = String(formData.get('order_id') || '');
  const provider = String(formData.get('provider') || '');
  if (!orderId || !provider) redirect(`/payment/${orderId}?error=missing`);
  const s = await createClient();
  const { data: { user } } = await s.auth.getUser();
  if (!user) redirect('/login');
  const { data: order } = await s.from('orders').select('id,total_amount,currency,buyer_id').eq('id', orderId).eq('buyer_id', user.id).maybeSingle();
  if (!order) redirect('/orders');
  const key = `${orderId}-${crypto.randomUUID()}-${Date.now()}`;
  const { data: paymentId, error } = await s.rpc('create_payment_intent', {
    p_order_id: order.id,
    p_provider: provider,
    p_idempotency_key: key,
  });
  if (error || !paymentId) redirect(`/payment/${orderId}?error=${encodeURIComponent(error?.message || 'payment')}`);
  redirect(`/payment/${orderId}/pending?payment=${paymentId}`);
}
