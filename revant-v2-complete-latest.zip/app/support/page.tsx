import Link from "next/link";
export default function Support() {
  return <main className="mx-auto min-h-screen max-w-3xl px-4 py-10">
    <Link href="/" className="text-sm font-semibold">← Revant</Link>
    <h1 className="mt-8 text-4xl font-semibold">Assistance</h1>
    <p className="mt-3 text-[var(--muted)]">Le centre de support Revant.</p>
  </main>;
}
