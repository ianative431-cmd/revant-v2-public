import type { Metadata } from "next";
import "./globals.css";
import CookieBanner from "@/components/cookie-banner";
import { CartProvider } from "@/components/cart";
export const metadata:Metadata={title:"Revant",description:"Marketplace Revant"};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="fr"><body><CartProvider>{children}</CartProvider><CookieBanner/></body></html>}
