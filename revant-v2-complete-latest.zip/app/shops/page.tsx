import Link from "next/link";
import { createClient } from "@/lib/supabase/server";

export default async function Shops() {
  const supabase = await createClient();
  const { data: shops } = await supabase.from("shops").select("id,name,slug,logo_url,city,is_pro,is_premium,is_restaurant").eq("status", "active").order("created_at", { ascending: false }).limit(40);
  return <main className="mx-auto min-h-screen max-w-7xl px-4 py-10">
    <Link href="/" className="text-sm font-semibold">← Revant</Link>
    <h1 className="mt-8 text-4xl font-black">Boutiques</h1><p className="mt-2 text-[var(--muted)]">Les boutiques actives de Revant.</p>
    {shops?.length ? <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">{shops.map(s => <Link key={s.id} href={`/shops/${s.slug}`} className="revant-card revant-hover p-5"><div className="flex h-20 w-20 items-center justify-center rounded-2xl bg-[var(--surface-2)] font-black">{s.name.slice(0,1).toUpperCase()}</div><h2 className="mt-4 font-bold">{s.name}</h2><p className="mt-1 text-sm text-[var(--muted)]">{s.city || "Niger"}</p>{s.is_premium && <span className="mt-3 inline-block rounded-full bg-amber-100 px-2.5 py-1 text-xs font-semibold">Premium</span>}</Link>)}</div> : <div className="mt-8 rounded-3xl border border-[var(--border)] bg-white p-8 text-[var(--muted)]">Aucune boutique active pour le moment.</div>}
  </main>;
}
