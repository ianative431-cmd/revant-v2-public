'use server';
import { createClient } from '@/lib/supabase/server';
import { redirect } from 'next/navigation';

export async function createOrder(formData: FormData) {
  const addressId = String(formData.get('address_id') || '');
  const raw = String(formData.get('items') || '[]');
  let items: any[] = [];
  try { items = JSON.parse(raw); } catch { redirect('/checkout?error=invalid'); }
  if (!addressId || !Array.isArray(items) || !items.length) redirect('/checkout?error=missing');
  const s = await createClient();
  const { data, error } = await s.rpc('checkout_create_order', {
    p_items: items.map((x:any) => ({ product_id: x.productId, quantity: x.quantity })),
    p_shipping_address_id: addressId,
    p_delivery: true,
  });
  if (error || !data) redirect('/checkout?error=' + encodeURIComponent(error?.message || 'order'));
  redirect(`/payment/${data}`);
}
