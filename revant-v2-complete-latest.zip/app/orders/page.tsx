import Link from 'next/link';
import { requireUser } from '@/lib/auth/guards';
import { createClient } from '@/lib/supabase/server';

const labels: Record<string,string> = { pending:"En attente", confirmed:"Confirmée", processing:"Préparation", ready_for_delivery:"Prête pour livraison", shipped:"Expédiée", delivered:"Livrée", cancelled:"Annulée", refunded:"Remboursée", disputed:"Litige" };
export default async function Orders() {
  const user = await requireUser(); const supabase = await createClient();
  const { data: orders } = await supabase.from('orders').select('id,order_number,status,total_amount,currency,created_at').eq('buyer_id', user.id).order('created_at',{ascending:false});
  return <main className="mx-auto min-h-screen max-w-7xl px-4 py-10"><Link href="/" className="text-sm font-semibold">← Revant</Link><h1 className="mt-8 text-4xl font-semibold">Mes commandes</h1><p className="mt-2 text-sm text-[var(--muted)]">Suivez vos commandes et leurs livraisons.</p><div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">{orders?.map((o:any)=><Link href={`/orders/${o.id}`} key={o.id} className="revant-card block p-5"><p className="font-semibold">Commande #{o.order_number}</p><p className="mt-1 text-sm text-[var(--muted)]">{labels[o.status] ?? o.status}</p><p className="mt-4 text-lg font-semibold">{Number(o.total_amount).toLocaleString('fr-FR')} {o.currency}</p><p className="mt-1 text-xs text-[var(--muted)]">{new Date(o.created_at).toLocaleString('fr-FR')}</p></Link>)}{!orders?.length&&<div className="revant-card p-8 text-sm text-[var(--muted)]">Aucune commande pour le moment.</div>}</div></main>;
}
