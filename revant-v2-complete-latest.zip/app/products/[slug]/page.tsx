import Link from "next/link";
import { notFound } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import AddToCart from '@/components/add-to-cart';

export default async function ProductPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const supabase = await createClient();
  const { data: product } = await supabase.from("products").select("id,name,slug,description,base_price,currency,stock_quantity,shop_id,category_id,brand_id").eq("slug", slug).eq("status", "active").maybeSingle();
  if (!product) notFound();
  const { data: images } = await supabase.from("product_images").select("id,image_url,alt_text,sort_order").eq("product_id", product.id).order("sort_order");
  const { data: shop } = await supabase.from("shops").select("name,slug").eq("id", product.shop_id).eq("status", "active").maybeSingle();
  return <main className="mx-auto min-h-screen max-w-6xl px-4 py-10"><Link href="/products" className="text-sm font-semibold">← Catalogue</Link><div className="mt-8 grid gap-8 md:grid-cols-2"><div className="grid gap-3 sm:grid-cols-2">{images?.length ? images.map(image=><img key={image.id} src={image.image_url} alt={image.alt_text || product.name} className="aspect-square w-full rounded-3xl object-cover"/>):<div className="aspect-square rounded-3xl bg-[var(--surface-2)]"/>}</div><div><p className="text-sm font-semibold text-[var(--accent)]">{shop?.name || "Revant"}</p><h1 className="mt-2 text-4xl font-black">{product.name}</h1><p className="mt-4 text-2xl font-bold">{Number(product.base_price).toLocaleString("fr-FR")} {product.currency}</p><p className="mt-5 leading-7 text-[var(--muted)]">{product.description || "Aucune description."}</p><p className="mt-4 text-sm">Stock : {product.stock_quantity}</p><AddToCart product={{id:product.id,name:product.name,price:Number(product.base_price),currency:product.currency,stock:product.stock_quantity,slug:product.slug,imageUrl:images?.[0]?.image_url}}/></div></div></main>;
}
