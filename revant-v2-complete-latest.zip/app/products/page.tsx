import Link from "next/link";
import { createClient } from "@/lib/supabase/server";

export default async function ProductsPage() {
  const supabase = await createClient();
  const { data: products } = await supabase.from("products").select("id,name,slug,description,base_price,currency,stock_quantity,shop_id").eq("status", "active").order("created_at", { ascending: false }).limit(40);
  return <main className="mx-auto min-h-screen max-w-7xl px-4 py-10">
    <Link href="/" className="text-sm font-semibold">← Revant</Link>
    <div className="mt-8"><p className="text-sm font-semibold text-[var(--accent)]">Catalogue</p><h1 className="mt-1 text-4xl font-black">Produits</h1></div>
    {products?.length ? <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">{products.map(p => <Link key={p.id} href={`/products/${p.slug}`} className="revant-card revant-hover p-5"><div className="aspect-square rounded-2xl bg-[var(--surface-2)]"/><h2 className="mt-4 font-bold">{p.name}</h2><p className="mt-1 text-sm text-[var(--muted)]">{Number(p.base_price).toLocaleString("fr-FR")} {p.currency}</p></Link>)}</div> : <div className="mt-8 rounded-3xl border border-[var(--border)] bg-white p-8 text-[var(--muted)]">Aucun produit actif pour le moment.</div>}
  </main>;
}
