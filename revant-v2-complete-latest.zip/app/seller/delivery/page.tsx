import Link from "next/link";
import { createClient } from "@/lib/supabase/server";
import { requestDelivery, updateDeliveryStatus } from "./actions";

const labels: Record<string,string> = { unassigned:"En attente d’un livreur", assigned:"Livreur assigné", picked_up:"Colis récupéré", in_transit:"En livraison", delivered:"Livrée", failed:"Échec", cancelled:"Annulée" };

export default async function SellerDeliveryPage() {
  const supabase = await createClient();
  const { data: claims } = await supabase.auth.getClaims();
  const userId = claims?.claims?.sub as string | undefined;
  if (!userId) return <main className="mx-auto max-w-5xl px-4 py-16"><Link href="/login?next=/seller/delivery" className="font-semibold">Se connecter</Link></main>;
  const { data: shops } = await supabase.from("shops").select("id,name").eq("owner_id", userId);
  const ids = (shops ?? []).map(s=>s.id);
  const { data: items } = ids.length ? await supabase.from("order_items").select("order_id,shop_id,product_name,quantity,orders(order_number,status,created_at)").in("shop_id",ids).limit(100) : {data:[] as any[]};
  const orderIds = [...new Set((items??[]).map((x:any)=>x.order_id))];
  const { data: deliveries } = orderIds.length ? await supabase.from("deliveries").select("id,order_id,driver_id,company_id,status,pickup_address,delivery_address,assigned_at,picked_up_at,delivered_at,failure_reason,drivers(full_name,phone,vehicle_type),delivery_companies(name,phone)").in("order_id",orderIds).order("created_at",{ascending:false}) : {data:[] as any[]};
  return <main className="min-h-screen bg-[var(--background)] px-4 py-8 sm:px-6"><div className="mx-auto max-w-6xl">
    <Link href="/seller" className="text-sm font-semibold text-[var(--accent)]">← Tableau de bord</Link>
    <h1 className="mt-4 text-4xl font-semibold">Livraisons</h1><p className="mt-2 text-[var(--muted)]">Suivez les livraisons liées aux commandes de vos boutiques.</p>
    <div className="mt-8 space-y-4">{deliveries?.length ? deliveries.map((d:any)=><div key={d.id} className="revant-card p-5"><div className="flex flex-wrap items-start justify-between gap-4"><div><p className="font-semibold">Commande #{(items??[]).find((x:any)=>x.order_id===d.order_id)?.orders?.order_number ?? d.order_id.slice(0,8)}</p><p className="mt-1 text-sm text-[var(--muted)]">{labels[d.status] ?? d.status}</p></div><div className="flex flex-wrap gap-2">{d.status === "unassigned" && <form action={requestDelivery}><input type="hidden" name="deliveryId" value={d.id}/><button className="rounded-xl bg-[var(--foreground)] px-4 py-2 text-sm font-semibold text-white">Demander un livreur</button></form>}<form action={updateDeliveryStatus} className="flex gap-2"><input type="hidden" name="deliveryId" value={d.id}/><select name="status" defaultValue={d.status} className="rounded-xl border border-[var(--border)] bg-transparent px-3 py-2 text-sm"><option value="unassigned">En attente d’un livreur</option><option value="assigned">Livreur assigné</option><option value="picked_up">Colis récupéré</option><option value="in_transit">En livraison</option><option value="delivered">Livrée</option><option value="failed">Échec</option><option value="cancelled">Annulée</option></select><button className="rounded-xl bg-[var(--foreground)] px-4 py-2 text-sm font-semibold text-white">Mettre à jour</button></form></div></div><div className="mt-4 grid gap-3 sm:grid-cols-3"><div><p className="text-xs text-[var(--muted)]">Retrait</p><p className="mt-1 text-sm">{d.pickup_address || "—"}</p></div><div><p className="text-xs text-[var(--muted)]">Destination</p><p className="mt-1 text-sm">{d.delivery_address || "—"}</p></div><div><p className="text-xs text-[var(--muted)]">Livreur</p><p className="mt-1 text-sm">{d.drivers?.full_name || "Non attribué"}{d.drivers?.vehicle_type ? ` · ${d.drivers.vehicle_type}` : ""}</p></div></div>{d.failure_reason&&<p className="mt-3 rounded-xl bg-[var(--surface-2)] p-3 text-sm">Motif : {d.failure_reason}</p>}</div>) : <div className="revant-card p-8 text-center text-sm text-[var(--muted)]">Aucune livraison n'est encore associée à vos commandes.</div>}</div>
  </div></main>;
}
