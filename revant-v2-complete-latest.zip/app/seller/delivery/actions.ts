"use server";
import { createClient } from "@/lib/supabase/server";
import { revalidatePath } from "next/cache";

const allowed = new Set(["unassigned","assigned","picked_up","in_transit","delivered","failed","cancelled"]);

export async function updateDeliveryStatus(formData: FormData) {
  const deliveryId = String(formData.get("deliveryId") || "");
  const status = String(formData.get("status") || "");
  if (!deliveryId || !allowed.has(status)) return;
  const supabase = await createClient();
  const { data: claims } = await supabase.auth.getClaims();
  if (!claims?.claims?.sub) return;
  await supabase.rpc("seller_update_delivery_status", { p_delivery_id: deliveryId, p_status: status });
  revalidatePath("/seller/delivery");
  revalidatePath("/seller");
}

export async function requestDelivery(formData: FormData) {
  const deliveryId = String(formData.get("deliveryId") || "");
  if (!deliveryId) return;
  const supabase = await createClient();
  const { data: claims } = await supabase.auth.getClaims();
  if (!claims?.claims?.sub) return;

  const { error } = await supabase.rpc("request_delivery_for_drivers", { p_delivery_id: deliveryId });
  if (error) throw new Error(error.message);

  // The Edge Function fans the request out to every registered driver device.
  // Database notifications remain the source of truth even if push delivery is unavailable.
  await supabase.functions.invoke("dispatch-delivery-notifications", { body: { deliveryId } });

  revalidatePath("/seller/delivery");
  revalidatePath("/driver");
}
