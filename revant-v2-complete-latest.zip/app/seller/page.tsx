import Link from "next/link";
import { createClient } from "@/lib/supabase/server";

const money = (n: number) => `${Math.round(n || 0).toLocaleString("fr-FR")} XOF`;

export default async function SellerDashboard() {
  const supabase = await createClient();
  const { data: claims } = await supabase.auth.getClaims();
  const userId = claims?.claims?.sub as string | undefined;
  if (!userId) return <main className="mx-auto max-w-5xl px-4 py-16"><Link href="/login?next=/seller" className="font-semibold">Se connecter</Link><h1 className="mt-8 text-4xl font-semibold">Tableau de bord vendeur</h1></main>;

  const { data: shops } = await supabase.from("shops").select("id,name,slug,status,is_pro,is_premium").eq("owner_id", userId).order("created_at", { ascending: false });
  const shopIds = (shops ?? []).map(s => s.id);
  const { data: products } = shopIds.length ? await supabase.from("products").select("id,name,base_price,stock_quantity,status,shop_id,product_images(image_url,alt_text)").in("shop_id", shopIds).order("created_at", { ascending: false }) : { data: [] as any[] };
  const { data: items } = shopIds.length ? await supabase.from("order_items").select("id,order_id,product_name,quantity,line_total,shop_id,orders(order_number,status,created_at,total_amount,currency)").in("shop_id", shopIds).order("created_at", { ascending: false }).limit(80) : { data: [] as any[] };
  const { data: reviews } = shopIds.length ? await supabase.from("reviews").select("id,rating,title,body,shop_id,created_at,is_published").in("shop_id", shopIds).order("created_at", { ascending: false }).limit(12) : { data: [] as any[] };
  const { data: conversations } = await supabase.from("conversations").select("id,shop_id,buyer_id,updated_at").eq("seller_id", userId).order("updated_at", { ascending: false }).limit(20);
  const { data: promotions } = shopIds.length ? await supabase.from("store_promotions").select("id,shop_id,status,placement,budget,start_at,end_at,views,visits,clicks,favorites,attributed_sales").in("shop_id", shopIds).order("created_at", { ascending: false }).limit(10) : { data: [] as any[] };
  const { data: wallet } = await supabase.from("wallets").select("available_balance,pending_balance,currency,status").eq("user_id", userId).maybeSingle();

  const delivered = (items ?? []).filter((x:any) => x.orders?.status === "delivered");
  const revenue = delivered.reduce((sum:number, x:any) => sum + Number(x.line_total || 0), 0);
  const pendingOrders = (items ?? []).filter((x:any) => ["pending","confirmed","processing","shipped","out_for_delivery"].includes(x.orders?.status)).length;
  const lowStock = (products ?? []).filter((p:any) => Number(p.stock_quantity) <= 5 && p.status !== "archived").length;
  const avgRating = reviews?.length ? reviews.reduce((s:number,r:any)=>s+Number(r.rating||0),0)/reviews.length : 0;

  return <main className="min-h-screen bg-[var(--background)] px-4 py-8 sm:px-6">
    <div className="mx-auto max-w-7xl">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div><Link href="/sell" className="text-sm font-semibold text-[var(--accent)]">← Ma boutique</Link><h1 className="mt-3 text-4xl font-semibold tracking-tight">Tableau de bord vendeur</h1><p className="mt-2 text-[var(--muted)]">Suivez vos ventes, votre catalogue et votre activité Revant.</p></div>
        <div className="flex gap-2"><Link href="/seller/delivery" className="rounded-xl border border-[var(--border)] px-4 py-2.5 text-sm font-semibold">Livraisons</Link><Link href="/sell" className="rounded-xl border border-[var(--border)] px-4 py-2.5 text-sm font-semibold">Gérer ma boutique</Link><Link href="/support" className="rounded-xl bg-[var(--foreground)] px-4 py-2.5 text-sm font-semibold text-white">Assistance</Link></div>
      </div>

      <section className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {[['Chiffre d’affaires',money(revenue),'Commandes livrées'],['Commandes à traiter',String(pendingOrders),'Toutes vos boutiques'],['Produits',String(products?.length ?? 0),`${lowStock} stock(s) faible(s)`],['Note moyenne',avgRating ? `${avgRating.toFixed(1)} / 5`:'—',`${reviews?.length ?? 0} avis récents`]].map(([a,b,c])=><div key={a} className="revant-card p-5"><p className="text-sm text-[var(--muted)]">{a}</p><p className="mt-2 text-3xl font-bold">{b}</p><p className="mt-1 text-xs text-[var(--muted)]">{c}</p></div>)}
      </section>

      <section className="mt-6 grid gap-6 lg:grid-cols-[1.4fr_.6fr]">
        <div className="revant-card overflow-hidden"><div className="flex items-center justify-between border-b border-[var(--border)] p-5"><div><h2 className="text-xl font-semibold">Commandes récentes</h2><p className="text-sm text-[var(--muted)]">Les commandes contenant vos produits.</p></div><span className="text-xs text-[var(--muted)]">{items?.length ?? 0} lignes</span></div><div className="divide-y divide-[var(--border)]">{items?.length ? items.slice(0,8).map((item:any)=><div key={item.id} className="flex items-center justify-between gap-4 p-5"><div><p className="font-semibold">{item.product_name}</p><p className="mt-1 text-xs text-[var(--muted)]">#{item.orders?.order_number ?? '—'} · ×{item.quantity} · {item.orders?.status ?? '—'}</p></div><strong>{money(Number(item.line_total))}</strong></div>) : <p className="p-5 text-sm text-[var(--muted)]">Aucune commande pour le moment.</p>}</div></div>
        <div className="revant-card p-5"><h2 className="text-xl font-semibold">Solde vendeur</h2><p className="mt-1 text-sm text-[var(--muted)]">Les retraits restent soumis aux règles KYC et de paiement.</p><div className="mt-6 rounded-2xl bg-[var(--surface-2)] p-5"><p className="text-sm text-[var(--muted)]">Disponible</p><p className="mt-1 text-3xl font-bold">{money(Number(wallet?.available_balance))}</p><p className="mt-4 text-sm text-[var(--muted)]">En attente : {money(Number(wallet?.pending_balance))}</p></div><Link href="/account" className="mt-4 inline-flex text-sm font-semibold text-[var(--accent)]">Ouvrir mon compte →</Link></div>
      </section>

      <section className="mt-6 grid gap-6 lg:grid-cols-2">
        <div className="revant-card p-5"><div className="flex items-center justify-between"><h2 className="text-xl font-semibold">Stock à surveiller</h2><Link href="/sell" className="text-sm font-semibold text-[var(--accent)]">Gérer</Link></div><div className="mt-4 space-y-3">{(products ?? []).filter((p:any)=>Number(p.stock_quantity)<=5).slice(0,6).map((p:any)=><div key={p.id} className="flex items-center justify-between rounded-2xl border border-[var(--border)] p-3"><div className="flex items-center gap-3"><div className="h-12 w-12 overflow-hidden rounded-xl bg-[var(--surface-2)]">{p.product_images?.[0]?.image_url && <img src={p.product_images[0].image_url} alt={p.product_images[0].alt_text || p.name} className="h-full w-full object-cover"/>}</div><div><p className="font-semibold">{p.name}</p><p className="text-xs text-[var(--muted)]">{money(Number(p.base_price))}</p></div></div><span className="rounded-full bg-[var(--surface-2)] px-3 py-1 text-xs font-semibold">Stock {p.stock_quantity}</span></div>)}{lowStock===0&&<p className="text-sm text-[var(--muted)]">Votre stock ne présente pas de niveau faible.</p>}</div></div>
        <div className="revant-card p-5"><div className="flex items-center justify-between"><h2 className="text-xl font-semibold">Messages</h2><Link href="/support" className="text-sm font-semibold text-[var(--accent)]">Assistance</Link></div><p className="mt-2 text-sm text-[var(--muted)]">Conversations acheteurs liées à vos boutiques.</p><div className="mt-5 rounded-2xl bg-[var(--surface-2)] p-5"><p className="text-3xl font-bold">{conversations?.length ?? 0}</p><p className="mt-1 text-sm text-[var(--muted)]">conversation(s) récente(s)</p></div></div>
      </section>

      <section className="mt-6 grid gap-6 lg:grid-cols-2">
        <div className="revant-card p-5"><h2 className="text-xl font-semibold">Avis clients</h2><div className="mt-4 space-y-3">{reviews?.slice(0,5).map((r:any)=><div key={r.id} className="rounded-2xl border border-[var(--border)] p-4"><div className="flex justify-between gap-3"><strong>{'★'.repeat(Number(r.rating||0))}{'☆'.repeat(5-Number(r.rating||0))}</strong><span className="text-xs text-[var(--muted)]">{r.is_published?'Publié':'En attente'}</span></div><p className="mt-2 font-semibold">{r.title || 'Avis client'}</p>{r.body&&<p className="mt-1 text-sm text-[var(--muted)]">{r.body}</p>}</div>)}{!reviews?.length&&<p className="text-sm text-[var(--muted)]">Aucun avis reçu.</p>}</div></div>
        <div className="revant-card p-5"><div className="flex items-center justify-between"><div><h2 className="text-xl font-semibold">Promotions</h2><p className="text-sm text-[var(--muted)]">Suivi des placements sponsorisés.</p></div><Link href="/sell" className="text-sm font-semibold text-[var(--accent)]">Créer</Link></div><div className="mt-4 space-y-3">{promotions?.map((p:any)=><div key={p.id} className="rounded-2xl border border-[var(--border)] p-4"><div className="flex justify-between gap-3"><strong>{p.placement}</strong><span className="text-xs">{p.status}</span></div><div className="mt-3 grid grid-cols-4 gap-2 text-center text-xs"><span><b className="block text-base">{p.views}</b>vues</span><span><b className="block text-base">{p.visits}</b>visites</span><span><b className="block text-base">{p.clicks}</b>clics</span><span><b className="block text-base">{p.favorites}</b>favoris</span></div></div>)}{!promotions?.length&&<p className="text-sm text-[var(--muted)]">Aucune promotion active ou enregistrée.</p>}</div></div>
      </section>
    </div>
  </main>;
}
