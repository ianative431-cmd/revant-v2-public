import Link from "next/link";
import { createClient } from "@/lib/supabase/server";
import { claimDelivery } from "./actions";
import DriverAutoClaim from "@/components/driver-auto-claim";
import DriverPush from "@/components/driver-push";

const labels: Record<string,string> = { unassigned:"En attente d’un livreur", assigned:"Livreur assigné", picked_up:"Colis récupéré", in_transit:"En livraison", delivered:"Livrée", failed:"Échec", cancelled:"Annulée" };

export default async function DriverPage({ searchParams }: { searchParams?: Promise<{ claim?: string }> }) {
  const supabase = await createClient();
  const { data: claims } = await supabase.auth.getClaims();
  const userId = claims?.claims?.sub as string | undefined;
  const claimId = (await searchParams)?.claim;
  if (!userId) return <main className="mx-auto max-w-4xl px-4 py-16"><Link href="/login?next=/driver" className="font-semibold">Se connecter</Link></main>;

  const { data: driver } = await supabase.from("drivers").select("id,full_name,phone,vehicle_type,status").eq("user_id", userId).maybeSingle();
  if (!driver) return <main className="mx-auto max-w-4xl px-4 py-16"><div className="revant-card p-8"><h1 className="text-2xl font-semibold">Espace livreur</h1><p className="mt-2 text-[var(--muted)]">Votre compte livreur n’est pas encore rattaché à ce compte.</p></div></main>;

  const { data: notifications } = await supabase.from("notifications").select("id,title,body,data,created_at,read_at").eq("user_id", userId).eq("type", "delivery").order("created_at", { ascending: false }).limit(30);
  const { data: deliveries } = await supabase.from("deliveries").select("id,order_id,status,pickup_address,delivery_address,assigned_at,picked_up_at,delivered_at").eq("driver_id", driver.id).order("created_at", { ascending: false }).limit(30);

  return <main className="min-h-screen bg-[var(--background)] px-4 py-8 sm:px-6"><div className="mx-auto max-w-6xl">
    <Link href="/account" className="text-sm font-semibold text-[var(--accent)]">← Mon compte</Link>
    <div className="mt-5 flex flex-wrap items-end justify-between gap-4"><div><p className="text-sm text-[var(--muted)]">Livreur</p><h1 className="text-4xl font-semibold">{driver.full_name}</h1><p className="mt-1 text-sm text-[var(--muted)]">{driver.vehicle_type || "Véhicule non renseigné"} · {driver.status}</p></div><div className="rounded-full border border-[var(--border)] px-4 py-2 text-sm">Notifications : {notifications?.length ?? 0}</div></div>

    <div className="mt-6"><DriverPush /></div>

    {claimId && <div className="mt-8"><DriverAutoClaim deliveryId={claimId} /></div>}

    <section className="mt-8"><h2 className="text-xl font-semibold">Nouvelles demandes</h2><div className="mt-4 space-y-3">{notifications?.filter((n:any)=>n.data?.kind === "delivery_request" && !n.read_at).map((n:any)=><div key={n.id} className="revant-card p-5"><p className="font-semibold">{n.title}</p><p className="mt-1 text-sm text-[var(--muted)]">{n.body}</p><form action={claimDelivery} className="mt-4"><input type="hidden" name="deliveryId" value={n.data?.delivery_id || ""}/><button className="rounded-xl bg-[var(--foreground)] px-5 py-3 text-sm font-semibold text-white">Ouvrir et prendre la livraison</button></form></div>)}{!(notifications?.some((n:any)=>n.data?.kind === "delivery_request" && !n.read_at)) && <div className="revant-card p-6 text-sm text-[var(--muted)]">Aucune nouvelle demande disponible.</div>}</div></section>

    <section className="mt-10"><h2 className="text-xl font-semibold">Mes livraisons</h2><div className="mt-4 grid gap-4 sm:grid-cols-2">{deliveries?.map((d:any)=><Link key={d.id} href={`/driver/${d.id}`} className="revant-card p-5 block"><p className="font-semibold">{labels[d.status] ?? d.status}</p><p className="mt-2 text-sm text-[var(--muted)]">{d.pickup_address || "Retrait non renseigné"}</p><p className="mt-1 text-sm">→ {d.delivery_address || "Destination non renseignée"}</p></Link>)}{!deliveries?.length && <div className="revant-card p-6 text-sm text-[var(--muted)]">Aucune livraison attribuée.</div>}</div></section>
  </div></main>;
}
