import Link from "next/link";
import { createClient } from "@/lib/supabase/server";
import { confirmDeliveryCode, updateDriverDeliveryStatus } from "../actions";

const labels: Record<string,string> = { unassigned:"En attente d’un livreur", assigned:"Livreur assigné", picked_up:"Colis récupéré", in_transit:"En livraison", delivered:"Livrée", failed:"Échec", cancelled:"Annulée" };
const steps = ["assigned","picked_up","in_transit","delivered"];

export default async function DriverDeliveryPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const supabase = await createClient();
  const { data: claims } = await supabase.auth.getClaims();
  const uid = claims?.claims?.sub as string | undefined;
  if (!uid) return <main className="mx-auto max-w-4xl px-4 py-16"><Link href={`/login?next=/driver/${id}`} className="font-semibold">Se connecter</Link></main>;
  const { data: delivery } = await supabase.from("deliveries").select("id,order_id,status,pickup_address,delivery_address,assigned_at,picked_up_at,delivered_at,delivery_code_hint,drivers(full_name,phone,vehicle_type)").eq("id", id).maybeSingle();
  if (!delivery) return <main className="mx-auto max-w-4xl px-4 py-16"><div className="revant-card p-8">Cette livraison n’est pas accessible.</div></main>;
  const currentIndex = steps.indexOf(delivery.status);
  const map = (address:string|null) => address ? `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(address)}` : "#";
  return <main className="min-h-screen bg-[var(--background)] px-4 py-8 sm:px-6"><div className="mx-auto max-w-4xl">
    <Link href="/driver" className="text-sm font-semibold text-[var(--accent)]">← Mes livraisons</Link>
    <div className="revant-card mt-5 p-6">
      <p className="text-sm text-[var(--muted)]">Livraison</p><h1 className="mt-1 text-3xl font-semibold">Commande #{delivery.order_id.slice(0,8)}</h1>
      <p className="mt-2 font-semibold">{labels[delivery.status] ?? delivery.status}</p>
      <div className="mt-7 grid grid-cols-4 gap-2">{steps.map((s,i)=><div key={s}><div className={`h-2 rounded-full ${i <= currentIndex ? "bg-[var(--foreground)]" : "bg-[var(--surface-2)]"}`}/><p className="mt-2 text-center text-[10px] sm:text-xs">{labels[s]}</p></div>)}</div>
      <div className="mt-7 grid gap-4 sm:grid-cols-2"><div className="rounded-2xl border border-[var(--border)] p-4"><p className="text-xs text-[var(--muted)]">Retrait</p><p className="mt-1">{delivery.pickup_address || "—"}</p>{delivery.pickup_address&&<a className="mt-3 inline-block text-sm font-semibold underline" href={map(delivery.pickup_address)} target="_blank" rel="noreferrer">Ouvrir dans Maps</a>}</div><div className="rounded-2xl border border-[var(--border)] p-4"><p className="text-xs text-[var(--muted)]">Destination</p><p className="mt-1">{delivery.delivery_address || "—"}</p>{delivery.delivery_address&&<a className="mt-3 inline-block text-sm font-semibold underline" href={map(delivery.delivery_address)} target="_blank" rel="noreferrer">Ouvrir dans Maps</a>}</div></div>
      {delivery.status === "assigned" && <form action={updateDriverDeliveryStatus} className="mt-7"><input type="hidden" name="deliveryId" value={id}/><input type="hidden" name="status" value="picked_up"/><button className="w-full rounded-2xl bg-[var(--foreground)] px-5 py-4 font-semibold text-white">📦 Confirmer le retrait du colis</button></form>}
      {delivery.status === "picked_up" && <form action={updateDriverDeliveryStatus} className="mt-7"><input type="hidden" name="deliveryId" value={id}/><input type="hidden" name="status" value="in_transit"/><button className="w-full rounded-2xl bg-[var(--foreground)] px-5 py-4 font-semibold text-white">🚚 Démarrer la livraison</button></form>}
      {delivery.status === "in_transit" && <div className="mt-7 rounded-2xl border border-[var(--border)] p-5"><h2 className="font-semibold">Confirmer la remise</h2><p className="mt-1 text-sm text-[var(--muted)]">Demandez au client son code à 4 chiffres. Le code ne doit être demandé qu’au moment où vous remettez réellement la commande.</p><form action={confirmDeliveryCode} className="mt-4 flex flex-wrap gap-3"><input type="hidden" name="deliveryId" value={delivery.id}/><input name="code" inputMode="numeric" pattern="[0-9]{4}" maxLength={4} placeholder="1234" className="w-32 rounded-xl border border-[var(--border)] bg-transparent px-4 py-3 text-center text-lg tracking-[0.4em]"/><button className="rounded-xl bg-[var(--foreground)] px-5 py-3 text-sm font-semibold text-white">Confirmer la livraison</button></form></div>}
      {delivery.status === "delivered" && <div className="mt-7 rounded-2xl border border-[var(--border)] p-5"><p className="font-semibold">Livraison terminée ✓</p><p className="mt-1 text-sm text-[var(--muted)]">La remise a été confirmée par le code client.</p></div>}
      {delivery.status === "assigned" || delivery.status === "picked_up" || delivery.status === "in_transit" ? <form action={updateDriverDeliveryStatus} className="mt-4"><input type="hidden" name="deliveryId" value={id}/><input type="hidden" name="status" value="failed"/><button className="text-sm font-semibold text-red-700 underline">Signaler un problème de livraison</button></form> : null}
    </div>
  </div></main>;
}
