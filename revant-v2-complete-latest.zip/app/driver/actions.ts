"use server";
import { createClient } from "@/lib/supabase/server";
import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";

export async function claimDelivery(formData: FormData) {
  const deliveryId = String(formData.get("deliveryId") || "");
  if (!deliveryId) return;
  const supabase = await createClient();
  const { data: claims } = await supabase.auth.getClaims();
  if (!claims?.claims?.sub) redirect(`/login?next=/driver`);
  const { error } = await supabase.rpc("claim_delivery", { p_delivery_id: deliveryId });
  if (error) { revalidatePath("/driver"); return; }
  revalidatePath("/driver");
  revalidatePath(`/driver/${deliveryId}`);
  redirect(`/driver/${deliveryId}`);
}

export async function updateDriverDeliveryStatus(formData: FormData) {
  const deliveryId = String(formData.get("deliveryId") || "");
  const status = String(formData.get("status") || "");
  if (!deliveryId || !["picked_up","in_transit","failed"].includes(status)) return;
  const supabase = await createClient();
  const { data: claims } = await supabase.auth.getClaims();
  if (!claims?.claims?.sub) redirect(`/login?next=/driver/${deliveryId}`);
  const { error } = await supabase.rpc("driver_update_delivery_status", { p_delivery_id: deliveryId, p_status: status });
  if (error) return;
  revalidatePath(`/driver/${deliveryId}`);
  revalidatePath("/driver");
}

export async function confirmDeliveryCode(formData: FormData) {
  const deliveryId = String(formData.get("deliveryId") || "");
  const code = String(formData.get("code") || "").trim();
  if (!deliveryId || !/^\d{4}$/.test(code)) return;
  const supabase = await createClient();
  const { data: claims } = await supabase.auth.getClaims();
  if (!claims?.claims?.sub) redirect(`/login?next=/driver/${deliveryId}`);
  await supabase.rpc("confirm_delivery_code", { p_delivery_id: deliveryId, p_code: code });
  revalidatePath(`/driver/${deliveryId}`);
  revalidatePath("/driver");
}
