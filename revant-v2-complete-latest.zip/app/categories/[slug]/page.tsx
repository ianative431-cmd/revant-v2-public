import Link from "next/link";
import { createClient } from "@/lib/supabase/server";

export default async function CategoryPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params; const supabase = await createClient();
  const { data: category } = await supabase.from("categories").select("id,name,slug,description").eq("slug", slug).eq("is_active", true).maybeSingle();
  const { data: products } = category ? await supabase.from("products").select("id,name,slug,base_price,currency").eq("category_id", category.id).eq("status", "active").limit(40) : { data: [] };
  return <main className="mx-auto min-h-screen max-w-7xl px-4 py-10"><Link href="/" className="text-sm font-semibold">← Revant</Link><h1 className="mt-8 text-4xl font-black">{category?.name || "Catégorie"}</h1><p className="mt-2 text-[var(--muted)]">{category?.description || "Produits disponibles dans cette catégorie."}</p><div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">{products?.map(p=><Link key={p.id} href={`/products/${p.slug}`} className="revant-card revant-hover p-4"><div className="aspect-square rounded-2xl bg-[var(--surface-2)]"/><h2 className="mt-3 font-bold">{p.name}</h2><p className="mt-1 text-sm text-[var(--muted)]">{Number(p.base_price).toLocaleString("fr-FR")} {p.currency}</p></Link>)}</div></main>;
}
