'use server';
import { createClient } from '@/lib/supabase/server';
import { revalidatePath } from 'next/cache';

async function call(fn: string, args: Record<string, unknown>) {
  const s = await createClient();
  const { error } = await s.rpc(fn, args);
  if (error) throw new Error(error.message);
  revalidatePath('/admin');
  revalidatePath('/admin/operations');
}
export async function updateUser(formData: FormData) { await call('admin_set_user_suspension',{p_user_id:String(formData.get('id')),p_suspended:String(formData.get('suspended'))==='true',p_reason:String(formData.get('reason')||'')}); }
export async function updateKyc(formData: FormData) { await call('admin_update_kyc',{p_kyc_id:String(formData.get('id')),p_action:String(formData.get('action')),p_reason:String(formData.get('reason')||'')}); }
export async function updateDispute(formData: FormData) { await call('admin_update_dispute',{p_dispute_id:String(formData.get('id')),p_action:String(formData.get('action')),p_note:String(formData.get('note')||'')}); }
export async function updateReport(formData: FormData) { await call('admin_update_report',{p_report_id:String(formData.get('id')),p_action:String(formData.get('action')),p_note:String(formData.get('note')||'')}); }
