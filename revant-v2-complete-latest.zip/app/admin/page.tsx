import Link from "next/link";
import { ArrowRight, Banknote, BookOpen, Boxes, CreditCard, FileCheck2, Gavel, Headphones, Settings, ShieldCheck, Store, Users } from "lucide-react";
import { requireAdmin } from "@/lib/auth/guards";
import { createClient } from "@/lib/supabase/server";

export default async function AdminPage() {
  await requireAdmin();
  const supabase = await createClient();
  const { data: snapshot, error } = await supabase.rpc("admin_overview_snapshot");
  if (error) throw new Error(error.message);
  const stats = (snapshot || {}) as Record<string, unknown>;
  const recentOrders = (stats.recent_orders || []) as Array<Record<string, unknown>>;
  const sections = [
    ["Utilisateurs", "/admin/users", Users],
    ["Boutiques", "/admin/shops", Store],
    ["Catalogue", "/admin/catalog", Boxes],
    ["Commandes", "/admin/orders", BookOpen],
    ["Paiements", "/admin/finance#payments", CreditCard],
    ["Finance", "/admin/finance", Banknote],
    ["Payouts", "/admin/finance#payouts", Banknote],
    ["KYC", "/admin/kyc", FileCheck2],
    ["Litiges", "/admin/disputes", Gavel],
    ["Support", "/admin/support", Headphones],
    ["Configuration", "/admin/settings", Settings],
    ["Opérations", "/admin/operations", ShieldCheck],
    ["Audit", "/admin/operations", ShieldCheck],
  ] as const;

  return (
    <main className="min-h-screen bg-[var(--background)] px-4 py-10">
      <div className="mx-auto max-w-7xl">
        <Link href="/" className="inline-flex items-center gap-2 text-sm font-semibold">← Revant</Link>
        <div className="mt-8 flex flex-col justify-between gap-4 sm:flex-row sm:items-end">
          <div>
            <p className="text-sm font-bold uppercase tracking-[.16em] text-[var(--accent)]">Espace sécurisé</p>
            <h1 className="mt-2 text-4xl font-black">Administration</h1>
            <p className="mt-2 text-[var(--muted)]">Pilotage centralisé de la marketplace Revant.</p>
          </div>
          <Link href="/admin/finance" className="inline-flex items-center gap-2 rounded-2xl bg-[var(--foreground)] px-4 py-3 text-sm font-bold text-white">Centre financier <ArrowRight size={17}/></Link>
        </div>
        <section className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <AdminStat label="Utilisateurs" value={stats.users} detail={`${stats.suspended_users ?? 0} suspendu(s)`} />
          <AdminStat label="Boutiques" value={stats.shops} detail={`${stats.active_shops ?? 0} actives`} />
          <AdminStat label="Produits" value={stats.products} detail={`${stats.pending_products ?? 0} en attente`} />
          <AdminStat label="Commandes" value={stats.orders} detail={`${stats.pending_orders ?? 0} en cours`} />
        </section>
        <section className="mt-4 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <AdminStat label="Litiges ouverts" value={stats.open_disputes} detail="À traiter" />
          <AdminStat label="KYC en attente" value={stats.pending_kyc} detail="Vérification requise" />
          <AdminStat label="Support ouvert" value={stats.open_support} detail="Tickets actifs" />
          <AdminStat label="Paiement" value={stats.payments_enabled ? "Actif" : "Préparé"} detail="Aucun débit sans fournisseur activé" />
        </section>

        <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {sections.map(([label, href, Icon]) => (
            <Link href={href} key={label} className="revant-card revant-hover flex items-center justify-between p-5">
              <span className="flex items-center gap-3 font-semibold"><span className="rounded-xl bg-[var(--surface-2)] p-2"><Icon size={19}/></span>{label}</span>
              <ArrowRight size={16}/>
            </Link>
          ))}
        </div>
        <section className="mt-6 revant-card overflow-hidden">
          <div className="flex items-center justify-between border-b border-[var(--border)] p-5">
            <div><h2 className="text-xl font-black">Commandes récentes</h2><p className="text-sm text-[var(--muted)]">Vue de contrôle rapide depuis l’administration.</p></div>
            <Link href="/admin/finance#payments" className="text-sm font-bold">Voir la finance →</Link>
          </div>
          <div className="divide-y divide-[var(--border)]">
            {recentOrders.length === 0 ? <div className="p-8 text-sm text-[var(--muted)]">Aucune commande.</div> : recentOrders.map(order => (
              <div key={String(order.id)} className="flex flex-col gap-2 p-5 sm:flex-row sm:items-center sm:justify-between">
                <div><p className="font-bold">#{String(order.order_number)}</p><p className="text-xs text-[var(--muted)]">{new Date(String(order.created_at)).toLocaleString("fr-FR")}</p></div>
                <div className="flex items-center gap-4"><strong>{Number(order.total_amount || 0).toLocaleString("fr-FR")} {String(order.currency || "XOF")}</strong><span className="rounded-full border border-[var(--border)] px-2.5 py-1 text-[11px] font-bold">{String(order.status)}</span></div>
              </div>
            ))}
          </div>
        </section>
      </div>
    </main>
  );
}

function AdminStat({ label, value, detail }: { label: string; value: unknown; detail: string }) {
  return <div className="revant-card p-5"><p className="text-xs font-bold uppercase tracking-wider text-[var(--muted)]">{label}</p><p className="mt-2 text-3xl font-black">{String(value ?? 0)}</p><p className="mt-1 text-xs text-[var(--muted)]">{detail}</p></div>;
}
