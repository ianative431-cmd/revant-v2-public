import Link from "next/link";
import { ArrowLeft, Banknote, CheckCircle2, CircleDollarSign, Clock3, CreditCard, ShieldCheck, XCircle } from "lucide-react";
import { requireAdmin } from "@/lib/auth/guards";
import { createClient } from "@/lib/supabase/server";
import { updatePayoutAction } from "./actions";

function money(value: unknown) {
  const n = Number(value || 0);
  return new Intl.NumberFormat("fr-FR", { maximumFractionDigits: 0 }).format(n) + " XOF";
}

export default async function AdminFinancePage() {
  await requireAdmin();
  const supabase = await createClient();
  const { data: snapshot, error: snapshotError } = await supabase.rpc("admin_finance_snapshot");
  if (snapshotError) throw new Error(snapshotError.message);
  const snapshotData = (snapshot || {}) as Record<string, unknown>;
  const s = (snapshotData.summary || {}) as Record<string, unknown>;
  const r = (snapshotData.rule || {}) as Record<string, unknown>;
  const rows = (snapshotData.payouts || []) as Array<Record<string, unknown>>;
  const providerRows = (snapshotData.providers || []) as Array<Record<string, unknown>>;
  const paymentRows = (snapshotData.payments || []) as Array<Record<string, unknown>>;

  return <main className="min-h-screen bg-[var(--background)] px-4 py-6 sm:px-6 lg:px-8">
    <div className="mx-auto max-w-7xl">
      <div className="flex items-center justify-between gap-4">
        <Link href="/admin" className="inline-flex items-center gap-2 text-sm font-semibold"><ArrowLeft size={17}/> Administration</Link>
        <span className="rounded-full border border-[var(--border)] bg-white px-3 py-1 text-xs font-bold">Finance sécurisée</span>
      </div>
      <div className="mt-8">
        <p className="text-sm font-bold uppercase tracking-[.16em] text-[var(--accent)]">Centre financier</p>
        <h1 className="mt-2 text-4xl font-black tracking-tight">Finance & Payouts</h1>
        <p className="mt-2 max-w-2xl text-[var(--muted)]">Suivi des paiements, commissions et retraits vendeurs. Les paiements et payouts réels restent désactivés tant qu’un fournisseur n’est pas configuré.</p>
      </div>

      <section className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <Stat icon={<CircleDollarSign size={20}/>} label="Volume payé" value={money(s.paid_volume)} />
        <Stat icon={<CreditCard size={20}/>} label="Paiements payés" value={String(s.paid_payments ?? 0)} />
        <Stat icon={<Banknote size={20}/>} label="Payouts en attente" value={money(s.pending_payout_amount)} />
        <Stat icon={<ShieldCheck size={20}/>} label="Commission Revant" value={money(s.commission_volume)} />
      </section>

      <section id="payments" className="mt-6 grid gap-6 lg:grid-cols-[1.2fr_.8fr]">
        <div className="revant-card overflow-hidden">
          <div className="border-b border-[var(--border)] p-5"><h2 className="text-xl font-black">Paiements récents</h2><p className="text-sm text-[var(--muted)]">Lecture seule tant que les fournisseurs ne sont pas activés.</p></div>
          <div className="divide-y divide-[var(--border)]">
            {paymentRows.length === 0 ? <div className="p-8 text-sm text-[var(--muted)]">Aucun paiement enregistré.</div> : paymentRows.map(p => <div key={String(p.id)} className="flex flex-col gap-2 p-5 sm:flex-row sm:items-center sm:justify-between"><div><p className="font-bold">{money(p.amount)} {String(p.currency || "XOF")}</p><p className="text-xs text-[var(--muted)]">Commande {String(p.order_id).slice(0, 8)} · {String(p.provider || "—")}</p></div><div className="text-left sm:text-right"><Status status={String(p.status || "")}/><p className="mt-1 text-xs text-[var(--muted)]">{p.paid_at ? `Payé le ${new Date(String(p.paid_at)).toLocaleString("fr-FR")}` : new Date(String(p.created_at)).toLocaleString("fr-FR")}</p></div></div>)}
          </div>
        </div>
        <div className="revant-card overflow-hidden">
          <div className="border-b border-[var(--border)] p-5"><h2 className="text-xl font-black">Fournisseurs</h2><p className="text-sm text-[var(--muted)]">Activation manuelle après configuration des identifiants.</p></div>
          <div className="divide-y divide-[var(--border)]">
            {providerRows.length === 0 ? <div className="p-8 text-sm text-[var(--muted)]">Aucun fournisseur configuré.</div> : providerRows.map(p => <div key={String(p.id)} className="flex items-center justify-between gap-4 p-5"><div><p className="font-bold">{String(p.name)}</p><p className="text-xs text-[var(--muted)]">{String(p.code)} · {Array.isArray(p.supported_currencies) ? p.supported_currencies.join(", ") : "XOF"}</p></div><span className={`rounded-full border px-2.5 py-1 text-[11px] font-bold ${p.enabled ? "border-emerald-300 text-emerald-700" : "border-[var(--border)] text-[var(--muted)]"}`}>{p.enabled ? "Actif" : "Désactivé"}</span></div>)}
          </div>
        </div>
      </section>

      <section className="mt-6 grid gap-6 lg:grid-cols-[1.5fr_.8fr]">
        <div className="revant-card overflow-hidden">
          <div className="flex items-center justify-between border-b border-[var(--border)] p-5">
            <div><h2 className="text-xl font-black">Demandes de retrait</h2><p className="text-sm text-[var(--muted)]">Approbation manuelle obligatoire.</p></div>
            <Clock3 size={21}/>
          </div>
          <div className="divide-y divide-[var(--border)]">
            {rows.length === 0 ? <div className="p-8 text-sm text-[var(--muted)]">Aucune demande de retrait pour le moment.</div> : rows.map(p => <PayoutRow key={String(p.id)} payout={p} />)}
          </div>
        </div>

        <div className="space-y-6">
          <div className="revant-card p-5">
            <h2 className="text-xl font-black">Règles XOF</h2>
            <div className="mt-5 space-y-3 text-sm">
              <Row label="Minimum" value={money(r.min_amount)} />
              <Row label="Maximum" value={money(r.max_amount)} />
              <Row label="Limite quotidienne" value="Aucune" />
              <Row label="KYC requis" value={r.kyc_required ? "Oui" : "Non"} />
              <Row label="Validation manuelle" value={r.manual_approval_required ? "Oui" : "Non"} />
              <Row label="Frais" value={Number(r.fee_percent || 0) + "%"} />
            </div>
          </div>
          <div className="revant-card p-5">
            <h2 className="text-xl font-black">État des paiements</h2>
            <div className="mt-4 flex items-center gap-3 rounded-2xl bg-[var(--surface-2)] p-4"><span className="h-2.5 w-2.5 rounded-full bg-amber-500"/><span className="text-sm font-semibold">Désactivés — intégration fournisseur requise</span></div>
            <p className="mt-3 text-xs leading-5 text-[var(--muted)]">Moneroo, Flutterwave et iPay sont préparés dans le backend, sans identifiants réels et sans activation automatique.</p>
          </div>
        </div>
      </section>
    </div>
  </main>;
}

function Stat({ icon, label, value }: { icon: React.ReactNode; label: string; value: string }) {
  return <div className="revant-card p-5"><div className="flex items-center justify-between"><span className="rounded-xl bg-[var(--accent-soft)] p-2 text-[var(--accent)]">{icon}</span></div><p className="mt-5 text-xs font-bold uppercase tracking-wider text-[var(--muted)]">{label}</p><p className="mt-1 text-2xl font-black">{value}</p></div>;
}
function Row({ label, value }: { label: string; value: string }) { return <div className="flex justify-between gap-4 border-b border-[var(--border)] pb-3 last:border-0"><span className="text-[var(--muted)]">{label}</span><strong>{value}</strong></div>; }
function PayoutRow({ payout: p }: { payout: Record<string, unknown> }) {
  const pending = p.status === "pending";
  return <div className="p-5"><div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between"><div><div className="flex items-center gap-2"><span className="font-black">{money(p.amount)} {String(p.currency || "XOF")}</span><Status status={String(p.status || "")}/></div><p className="mt-1 text-xs text-[var(--muted)]">Vendeur {String(p.seller_id).slice(0, 8)} · {String(p.destination_type || "destination")} · {String(p.destination_reference || "—")}</p><p className="mt-1 text-xs text-[var(--muted)]">Demandé le {new Date(String(p.requested_at)).toLocaleString("fr-FR")}</p></div>{pending && <div className="flex gap-2"><form action={updatePayoutAction}><input type="hidden" name="payout_id" value={String(p.id)}/><input type="hidden" name="action" value="approve"/><button className="inline-flex items-center gap-1 rounded-xl bg-[var(--foreground)] px-3 py-2 text-xs font-bold text-white"><CheckCircle2 size={15}/> Approuver</button></form><form action={updatePayoutAction}><input type="hidden" name="payout_id" value={String(p.id)}/><input type="hidden" name="action" value="reject"/><input type="hidden" name="reason" value="Rejeté depuis le centre financier"/><button className="inline-flex items-center gap-1 rounded-xl border border-[var(--border)] px-3 py-2 text-xs font-bold"><XCircle size={15}/> Rejeter</button></form></div>}</div></div>;
}
function Status({ status }: { status: string }) { const map: Record<string,string> = { pending:"En attente", approved:"Approuvé", processing:"Traitement", paid:"Payé", rejected:"Rejeté", failed:"Échec", cancelled:"Annulé" }; return <span className="rounded-full border border-[var(--border)] px-2.5 py-1 text-[11px] font-bold">{map[status] || status}</span>; }
