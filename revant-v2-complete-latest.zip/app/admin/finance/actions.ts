"use server";

import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";

export async function updatePayoutAction(formData: FormData) {
  const payoutId = String(formData.get("payout_id") || "");
  const action = String(formData.get("action") || "");
  const reason = String(formData.get("reason") || "").trim() || null;
  if (!payoutId || !["approve", "reject"].includes(action)) throw new Error("Action invalide");

  const supabase = await createClient();
  const { error } = await supabase.rpc("admin_update_payout", {
    p_payout_id: payoutId,
    p_action: action,
    p_reason: reason,
  } as never);
  if (error) throw new Error(error.message);
  revalidatePath("/admin/finance");
}
