'use server';

import { createClient } from "@/lib/supabase/server";
import { redirect } from "next/navigation";

function slugify(value: string) {
  return value.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");
}

async function currentUser() {
  const supabase = await createClient();
  const { data } = await supabase.auth.getClaims();
  const id = data?.claims?.sub as string | undefined;
  if (!id) redirect("/login?next=/sell");
  return { supabase, id };
}

function text(formData: FormData, key: string) {
  return String(formData.get(key) ?? "").trim() || null;
}

async function uploadImage(supabase: Awaited<ReturnType<typeof createClient>>, bucket: string, userId: string, file: FormDataEntryValue | null, folder: string) {
  if (!(file instanceof File) || file.size === 0) return null;
  if (!file.type.startsWith("image/") || file.size > 8 * 1024 * 1024) return "INVALID";
  const ext = file.name.split(".").pop()?.toLowerCase() || "jpg";
  const path = `${userId}/${folder}/${crypto.randomUUID()}.${ext}`;
  const { error } = await supabase.storage.from(bucket).upload(path, file, { contentType: file.type, upsert: false });
  if (error) return "INVALID";
  return supabase.storage.from(bucket).getPublicUrl(path).data.publicUrl;
}

export async function createShop(formData: FormData) {
  const { supabase, id } = await currentUser();
  const name = String(formData.get("name") ?? "").trim();
  if (!name) redirect("/sell?error=shop");
  const slug = `${slugify(name)}-${id.slice(0, 6)}`;
  const logo = await uploadImage(supabase, "shop-media", id, formData.get("logo"), "logo");
  const banner = await uploadImage(supabase, "shop-media", id, formData.get("banner"), "banner");
  if (logo === "INVALID" || banner === "INVALID") redirect("/sell?error=shop-image");
  const { error } = await supabase.from("shops").insert({ owner_id: id, name, slug, description: text(formData, "description"), city: text(formData, "city"), phone: text(formData, "phone"), whatsapp: text(formData, "whatsapp"), logo_url: logo, banner_url: banner, background_color: text(formData, "background_color") || "#f6f4f1", status: "draft" });
  if (error) redirect("/sell?error=shop");
  redirect("/sell?saved=shop");
}

export async function updateShop(formData: FormData) {
  const { supabase, id } = await currentUser();
  const shopId = String(formData.get("shop_id") ?? "");
  const name = String(formData.get("name") ?? "").trim();
  if (!shopId || !name) redirect("/sell?error=shop-edit");
  const { data: shop } = await supabase.from("shops").select("id,slug,logo_url,banner_url").eq("id", shopId).eq("owner_id", id).maybeSingle();
  if (!shop) redirect("/sell?error=shop-edit");
  const logo = await uploadImage(supabase, "shop-media", id, formData.get("logo"), `${shopId}/logo`);
  const banner = await uploadImage(supabase, "shop-media", id, formData.get("banner"), `${shopId}/banner`);
  if (logo === "INVALID" || banner === "INVALID") redirect("/sell?error=shop-image");
  const { error } = await supabase.from("shops").update({
    name,
    slug: `${slugify(name)}-${id.slice(0, 6)}`,
    description: text(formData, "description"), city: text(formData, "city"), phone: text(formData, "phone"),
    whatsapp: text(formData, "whatsapp"), instagram: text(formData, "instagram"), tiktok: text(formData, "tiktok"), snapchat: text(formData, "snapchat"),
    background_color: text(formData, "background_color") || "#f6f4f1",
    logo_url: logo && logo !== "INVALID" ? logo : shop.logo_url,
    banner_url: banner && banner !== "INVALID" ? banner : shop.banner_url,
  }).eq("id", shopId).eq("owner_id", id);
  if (error) redirect("/sell?error=shop-edit");
  redirect("/sell?saved=shop-edit");
}

export async function createProduct(formData: FormData) {
  const { supabase, id } = await currentUser();
  const shopId = String(formData.get("shop_id") ?? "");
  const name = String(formData.get("name") ?? "").trim();
  const price = Number(formData.get("base_price") ?? 0);
  const stock = Number(formData.get("stock_quantity") ?? 0);
  if (!shopId || !name || !Number.isFinite(price) || price < 0 || !Number.isInteger(stock) || stock < 0) redirect("/sell?error=product");
  const { data: shop } = await supabase.from("shops").select("id").eq("id", shopId).eq("owner_id", id).maybeSingle();
  if (!shop) redirect("/sell?error=product");
  const slug = `${slugify(name)}-${crypto.randomUUID().slice(0, 8)}`;
  const { data: product, error } = await supabase.from("products").insert({ shop_id: shopId, name, slug, description: text(formData, "description"), base_price: price, currency: "XOF", stock_quantity: stock, status: "pending", is_featured: false }).select("id").single();
  if (error || !product) redirect("/sell?error=product");
  const file = formData.get("image");
  if (file instanceof File && file.size > 0) {
    if (!file.type.startsWith("image/") || file.size > 8 * 1024 * 1024) redirect("/sell?error=image");
    const ext = file.name.split(".").pop()?.toLowerCase() || "jpg";
    const path = `${id}/${product.id}/${crypto.randomUUID()}.${ext}`;
    const { error: uploadError } = await supabase.storage.from("product-images").upload(path, file, { contentType: file.type, upsert: false });
    if (uploadError) redirect("/sell?error=image");
    const { data: publicData } = supabase.storage.from("product-images").getPublicUrl(path);
    const { error: imageError } = await supabase.from("product_images").insert({ product_id: product.id, image_url: publicData.publicUrl, alt_text: name, sort_order: 0 });
    if (imageError) redirect("/sell?error=image");
  }
  redirect("/sell?saved=product");
}
