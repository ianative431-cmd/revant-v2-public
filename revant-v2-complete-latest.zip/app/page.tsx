import Link from "next/link";
import { ArrowRight, Headphones, Search, ShoppingBag, Sparkles, Store } from "lucide-react";
import { getPublicCatalog } from "@/lib/catalog/public";
import { createClient } from "@/lib/supabase/server";

export default async function Home(){
 const supabase = await createClient();
 const { data: { user } } = await supabase.auth.getUser();
 const { categories, brands, shops, products } = await getPublicCatalog();
 return <main className="min-h-screen">
  <header className="sticky top-0 z-30 border-b border-[var(--border)] bg-white/85 backdrop-blur-xl">
   <div className="mx-auto flex max-w-7xl items-center gap-3 px-4 py-4">
    <Link href="/" className="text-2xl font-black tracking-[-.04em]">REVANT</Link>
    <div className="hidden flex-1 md:block"><div className="mx-auto flex max-w-xl items-center gap-2 rounded-full border border-[var(--border)] bg-[var(--background)] px-4 py-2.5">
      <Search size={18}/><input aria-label="Rechercher" className="w-full bg-transparent outline-none" placeholder="Rechercher un produit, une boutique..."/>
    </div></div>
    <Link href="/support" aria-label="Assistance" className="rounded-full p-2.5 transition hover:bg-black/5"><Headphones size={20}/></Link>
    <Link href={user ? "/account" : "/login"} className="rounded-full bg-[var(--foreground)] px-4 py-2.5 text-sm font-semibold text-white transition hover:opacity-90">{user ? "Mon compte" : "Connexion"}</Link>
   </div>
  </header>
  <section className="mx-auto max-w-7xl px-4 pb-12 pt-8 md:pt-14">
   <div className="relative overflow-hidden rounded-[36px] border border-black/5 bg-[linear-gradient(135deg,#dedcdc,#f1ece7)] p-7 md:p-14">
    <div className="pointer-events-none absolute -right-16 -top-20 h-64 w-64 rounded-full bg-white/45 blur-3xl"/>
    <div className="revant-rise relative">
     <div className="mb-4 inline-flex items-center gap-2 rounded-full border border-black/10 bg-white/65 px-3 py-1.5 text-xs font-semibold"><Sparkles size={14}/> L'expérience Revant</div>
     <h1 className="max-w-3xl text-4xl font-black tracking-[-.05em] md:text-6xl">Achetez, vendez et découvrez autrement.</h1>
     <p className="mt-5 max-w-2xl text-lg leading-8 text-[var(--muted)]">Une marketplace élégante pour les acheteurs, vendeurs, restaurants et professionnels.</p>
     <div className="mt-8 flex flex-wrap gap-3">
      <Link href="/shops" className="group inline-flex items-center gap-2 rounded-full bg-[var(--foreground)] px-5 py-3 font-semibold text-white">Découvrir les boutiques <ArrowRight size={17} className="transition group-hover:translate-x-1"/></Link>
      <Link href="/sell" className="rounded-full border border-black/10 bg-white/80 px-5 py-3 font-semibold transition hover:bg-white">Vendre sur Revant</Link>
     </div>
    </div>
   </div>
   <section className="mt-10">
    <div className="mb-4 flex items-end justify-between"><div><p className="text-sm font-semibold text-[var(--accent)]">Explorer</p><h2 className="text-2xl font-bold">Catégories</h2></div></div>
    <div className="grid grid-cols-2 gap-3 md:grid-cols-5">{categories.map((c,i)=><Link style={{animationDelay:`${i*60}ms`}} key={c.id} href={`/categories/${c.slug}`} className="revant-card revant-hover revant-rise p-5 font-semibold">{c.name}</Link>)}</div>
   </section>
   <section className="mt-10">
    <div className="mb-4 flex items-end justify-between"><div><p className="text-sm font-semibold text-[var(--accent)]">Nouveautés</p><h2 className="text-2xl font-bold">Produits disponibles</h2></div><Link href="/products" className="text-sm font-semibold">Voir tout →</Link></div>
    {products.length ? <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">{products.slice(0,8).map((p,i)=><Link style={{animationDelay:`${i*50}ms`}} key={p.id} href={`/products/${p.slug}`} className="revant-card revant-hover revant-rise p-4"><div className="aspect-square rounded-2xl bg-[var(--surface-2)]"/><h3 className="mt-3 font-bold">{p.name}</h3><p className="mt-1 text-sm text-[var(--muted)]">{Number(p.base_price).toLocaleString("fr-FR")} {p.currency}</p></Link>)}</div> : <div className="rounded-3xl border border-[var(--border)] bg-white p-6 text-sm text-[var(--muted)]">Le catalogue se remplira dès que les premières annonces seront publiées.</div>}
   </section>

   <section className="mt-10">
    <div className="mb-4 flex items-end justify-between"><div><p className="text-sm font-semibold text-[var(--accent)]">Marketplace</p><h2 className="text-2xl font-bold">Boutiques actives</h2></div><Link href="/shops" className="text-sm font-semibold">Voir tout →</Link></div>
    {shops.length ? <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">{shops.slice(0,4).map(s=><Link key={s.id} href={`/shops/${s.slug}`} className="revant-card revant-hover p-5"><div className="h-16 w-16 rounded-2xl bg-[var(--surface-2)]"/><h3 className="mt-3 font-bold">{s.name}</h3><p className="mt-1 text-sm text-[var(--muted)]">{s.city || "Niger"}</p></Link>)}</div> : <div className="rounded-3xl border border-[var(--border)] bg-white p-6 text-sm text-[var(--muted)]">Les boutiques actives apparaîtront ici.</div>}
   </section>

   <section className="mt-10 grid gap-4 md:grid-cols-3">
    <Feature href="/shops" icon={<Store/>} title="Ma boutique" text="Personnalisez votre boutique et gérez vos produits."/>
    <Feature href="/orders" icon={<ShoppingBag/>} title="Mes commandes" text="Suivez achats, ventes et reçus."/>
    <Feature href="/support" icon={<Headphones/>} title="Assistance" text="Un accès direct au centre de support."/>
   </section>
  </section>
 </main>
}
function Feature({href,icon,title,text}:{href:string;icon:React.ReactNode;title:string;text:string}){return <Link href={href} className="revant-card revant-hover p-6"><div className="mb-4 inline-flex rounded-2xl bg-[var(--surface-2)] p-3">{icon}</div><h3 className="text-lg font-bold">{title}</h3><p className="mt-1 text-sm leading-6 text-[var(--muted)]">{text}</p></Link>}
