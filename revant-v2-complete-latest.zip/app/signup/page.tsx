import Link from 'next/link';
import { signUp } from './actions';

export default async function SignupPage({ searchParams }: { searchParams: Promise<{ error?: string }> }) {
  const params = await searchParams;
  return <main className="grid min-h-screen place-items-center p-4">
    <section className="revant-card w-full max-w-md p-7">
      <Link href="/" className="text-2xl font-black tracking-[-.04em]">REVANT</Link>
      <h1 className="mt-10 text-3xl font-bold">Créer un compte</h1>
      <p className="mt-2 text-sm text-[var(--muted)]">Créez votre espace acheteur Revant. Vous pourrez ensuite activer les fonctions vendeur.</p>
      {params.error && <p className="mt-4 rounded-2xl bg-[#f9e8e5] p-3 text-sm">Vérifiez les informations saisies. Le mot de passe doit contenir au moins 8 caractères et les deux mots de passe doivent correspondre.</p>}
      <form action={signUp} className="mt-7 space-y-4">
        <label className="block text-sm font-semibold">Nom complet<input name="display_name" required autoComplete="name" className="mt-2 w-full rounded-2xl border border-[var(--border)] bg-white p-3 outline-none focus:ring-2 focus:ring-[var(--accent-soft)]" /></label>
        <label className="block text-sm font-semibold">E-mail<input name="email" type="email" required autoComplete="email" className="mt-2 w-full rounded-2xl border border-[var(--border)] bg-white p-3 outline-none focus:ring-2 focus:ring-[var(--accent-soft)]" /></label>
        <label className="block text-sm font-semibold">Téléphone (+227)<input name="phone" type="tel" inputMode="tel" autoComplete="tel" placeholder="+227 …" className="mt-2 w-full rounded-2xl border border-[var(--border)] bg-white p-3 outline-none focus:ring-2 focus:ring-[var(--accent-soft)]" /></label>
        <label className="block text-sm font-semibold">Mot de passe<input name="password" type="password" minLength={8} required autoComplete="new-password" className="mt-2 w-full rounded-2xl border border-[var(--border)] bg-white p-3 outline-none focus:ring-2 focus:ring-[var(--accent-soft)]" /></label>
        <label className="block text-sm font-semibold">Confirmer le mot de passe<input name="password_confirmation" type="password" minLength={8} required autoComplete="new-password" className="mt-2 w-full rounded-2xl border border-[var(--border)] bg-white p-3 outline-none focus:ring-2 focus:ring-[var(--accent-soft)]" /></label>
        <button className="w-full rounded-2xl bg-[var(--foreground)] p-3 font-semibold text-white transition hover:opacity-90">Créer mon compte</button>
      </form>
      <p className="mt-6 text-center text-sm text-[var(--muted)]">Vous avez déjà un compte ? <Link className="font-semibold text-[var(--accent)]" href="/login">Se connecter</Link></p>
    </section>
  </main>;
}
