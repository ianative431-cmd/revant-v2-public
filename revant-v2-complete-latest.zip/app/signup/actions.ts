'use server';

import { createClient } from '@/lib/supabase/server';
import { redirect } from 'next/navigation';

export async function signUp(formData: FormData) {
  const displayName = String(formData.get('display_name') ?? '').trim();
  const email = String(formData.get('email') ?? '').trim().toLowerCase();
  const phone = String(formData.get('phone') ?? '').trim();
  const password = String(formData.get('password') ?? '');
  const confirmation = String(formData.get('password_confirmation') ?? '');

  if (!displayName || !email || password.length < 8 || password !== confirmation) {
    redirect('/signup?error=invalid');
  }

  const supabase = await createClient();
  const { data, error } = await supabase.auth.signUp({
    email,
    password,
    options: {
      data: {
        display_name: displayName,
        phone: phone || null,
        country_code: 'NE',
      },
    },
  });

  if (error) redirect('/signup?error=exists');

  if (data.session) redirect('/account');
  redirect('/login?check_email=1');
}
