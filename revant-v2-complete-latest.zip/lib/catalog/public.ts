import { createClient } from "@/lib/supabase/server";

export async function getPublicCatalog() {
  const supabase = await createClient();
  const [{ data: categories }, { data: brands }, { data: shops }, { data: products }] = await Promise.all([
    supabase.from("categories").select("id,name,slug,image_url").eq("is_active", true).order("sort_order").limit(12),
    supabase.from("brands").select("id,name,slug,logo_url,official_url").eq("is_active", true).order("name").limit(12),
    supabase.from("shops").select("id,name,slug,logo_url,banner_url,city,is_pro,is_premium,is_restaurant").eq("status", "active").order("created_at", { ascending: false }).limit(8),
    supabase.from("products").select("id,name,slug,description,base_price,currency,stock_quantity,is_featured,shop_id,category_id,brand_id").eq("status", "active").order("is_featured", { ascending: false }).order("created_at", { ascending: false }).limit(12),
  ]);
  return { categories: categories ?? [], brands: brands ?? [], shops: shops ?? [], products: products ?? [] };
}
