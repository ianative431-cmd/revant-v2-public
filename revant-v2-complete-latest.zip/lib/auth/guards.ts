import { redirect } from 'next/navigation';
import { createClient } from '@/lib/supabase/server';

export async function requireUser() {
  const supabase = await createClient();
  const { data, error } = await supabase.auth.getClaims();
  const userId = data?.claims?.sub;
  if (error || !userId) redirect('/login');
  return { id: userId, email: typeof data.claims.email === 'string' ? data.claims.email : null };
}

export async function requireAdmin() {
  const user = await requireUser();
  const supabase = await createClient();
  const { data: isAdmin, error } = await supabase.rpc('has_any_admin_role');
  if (error || !isAdmin) redirect('/');
  return user;
}
