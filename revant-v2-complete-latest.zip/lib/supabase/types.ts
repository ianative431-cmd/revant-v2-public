// Generated database types should be refreshed from the Revant Supabase project
// whenever the schema changes. The application intentionally avoids service-role
// credentials and uses the publishable key with RLS.
export type Json = string | number | boolean | null | { [key: string]: Json | undefined } | Json[];
export type Database = {
  public: {
    Tables: Record<string, any>;
    Views: Record<string, any>;
    Functions: {
      create_payment_intent: { Args: { p_order_id: string; p_provider: string; p_idempotency_key: string }; Returns: string };
      checkout_create_order: { Args: { p_items: Json; p_shipping_address_id: string; p_delivery?: boolean }; Returns: string };
      admin_finance_snapshot: { Args: Record<string, never>; Returns: Json };
      admin_update_payout: { Args: { p_payout_id: string; p_action: string; p_reason?: string | null }; Returns: undefined };
    };
    Enums: Record<string, string>;
    CompositeTypes: Record<string, any>;
  };
};
