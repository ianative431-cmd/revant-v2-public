# Revant V2 — consolidated build

This archive continues the current Revant V2 frontend against the existing Supabase project.

## Current modules
- Authentication and account
- Public catalog, shops, cart and checkout
- Buyer orders and delivery tracking
- Seller dashboard, Ma boutique, products and delivery
- Driver delivery flow and push registration hooks
- Secure Admin area and Finance/Payouts
- Payment-provider inventory for Moneroo, Flutterwave and iPay
- Secure payment-intent RPC with idempotency
- Finance release integration triggered by delivered orders / paid payments

## Payment state
Real online payments remain disabled until a provider is configured with real credentials and explicitly enabled by administration.

## Withdrawal rules
XOF: minimum 1,000; maximum 1,000,000; no daily limit; KYC required; manual approval required; zero fee.

## Security
The latest Supabase security advisor check returned 0 lints. No service-role credential is included in the frontend archive.

## Validation note
The archive was structurally checked with `unzip -t`. A full Next.js production build was not completed because dependency installation timed out in this environment.

## Admin operations consolidation
- `/admin/operations` added for users, KYC, disputes, reports and audit.
- Server actions call protected Supabase RPCs.
- Protected RPCs: `admin_set_user_suspension`, `admin_update_kyc`, `admin_update_dispute`, `admin_update_report`.
- Sensitive admin mutations are server-side and audited.
