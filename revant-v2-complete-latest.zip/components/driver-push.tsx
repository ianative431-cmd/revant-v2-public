"use client";
import { useEffect, useState } from "react";
import { createClient } from "@/lib/supabase/client";

export default function DriverPush() {
  const [state, setState] = useState<"idle"|"enabled"|"blocked"|"unsupported">("idle");
  useEffect(() => {
    if (!("Notification" in window) || !("serviceWorker" in navigator)) { setState("unsupported"); return; }
    if (Notification.permission === "granted") setState("enabled");
    else if (Notification.permission === "denied") setState("blocked");
  }, []);
  async function enable() {
    if (!("Notification" in window)) return;
    const permission = await Notification.requestPermission();
    setState(permission === "granted" ? "enabled" : "blocked");
    if (permission !== "granted") return;
    try {
      const registration = await navigator.serviceWorker.register("/sw.js");
      const existing = await registration.pushManager.getSubscription();
      const subscription = existing || await registration.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: process.env.NEXT_PUBLIC_VAPID_PUBLIC_KEY });
      const supabase = createClient();
      const { data: claims } = await supabase.auth.getClaims();
      const userId = claims?.claims?.sub as string | undefined;
      if (!userId || !subscription) return;
      await supabase.from("device_push_tokens").upsert({ user_id:userId, provider:"web", token:JSON.stringify(subscription.toJSON()), device_label:navigator.userAgent.slice(0,100), is_active:true, last_seen_at:new Date().toISOString(), updated_at:new Date().toISOString() }, { onConflict:"provider,token" });
    } catch { setState("blocked"); }
  }
  return <div className="revant-card p-5"><div className="flex flex-wrap items-center justify-between gap-4"><div><p className="font-semibold">Notifications de livraison</p><p className="mt-1 text-sm text-[var(--muted)]">Recevez les nouvelles courses même lorsque vous êtes sur une autre page.</p></div><button onClick={enable} disabled={state === "enabled"} className="rounded-xl bg-[var(--foreground)] px-4 py-2.5 text-sm font-semibold text-white disabled:opacity-50">{state === "enabled" ? "Activées" : state === "blocked" ? "Autoriser dans le navigateur" : "Activer"}</button></div></div>;
}
