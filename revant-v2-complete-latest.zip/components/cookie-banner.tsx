'use client';
import {useEffect,useState} from 'react';
export default function CookieBanner(){
 const [open,setOpen]=useState(false);
 useEffect(()=>{setOpen(localStorage.getItem('revant-cookie-choice')===null)},[]);
 if(!open)return null;
 const choose=(v:'necessary'|'all')=>{localStorage.setItem('revant-cookie-choice',v);setOpen(false)};
 return <aside className="fixed bottom-3 left-3 right-3 z-50 mx-auto max-w-2xl rounded-3xl border border-[var(--border)] bg-white p-5 shadow-2xl">
  <p className="text-sm font-bold">Votre confidentialité compte</p>
  <p className="mt-1 text-sm leading-6 text-[var(--muted)]">Revant utilise les cookies nécessaires au fonctionnement du site. Les cookies optionnels restent désactivés sans votre accord.</p>
  <div className="mt-4 flex flex-wrap gap-2">
   <button onClick={()=>choose('necessary')} className="rounded-full border border-[var(--border)] px-4 py-2 text-sm font-semibold">Nécessaires seulement</button>
   <button onClick={()=>choose('all')} className="rounded-full bg-[var(--foreground)] px-4 py-2 text-sm font-semibold text-white">Accepter tout</button>
  </div>
 </aside>
}
