'use client';
import { createContext, useContext, useEffect, useMemo, useState } from 'react';
import Link from 'next/link';

type CartItem={productId:string;name:string;price:number;currency:string;imageUrl?:string|null;quantity:number;stock:number;slug:string};
type CartContext={items:CartItem[];add:(item:Omit<CartItem,'quantity'>)=>void;remove:(id:string)=>void;setQty:(id:string,q:number)=>void;clear:()=>void;count:number;total:number};
const C=createContext<CartContext|null>(null);
export function CartProvider({children}:{children:React.ReactNode}){const [items,setItems]=useState<CartItem[]>([]);useEffect(()=>{try{const x=localStorage.getItem('revant-cart');if(x)setItems(JSON.parse(x))}catch{}},[]);useEffect(()=>{localStorage.setItem('revant-cart',JSON.stringify(items))},[items]);const value=useMemo(()=>({items,add:(item:Omit<CartItem,'quantity'>)=>setItems(a=>{const f=a.find(x=>x.productId===item.productId);return f?a.map(x=>x.productId===item.productId?{...x,quantity:Math.min(x.quantity+1,x.stock)}:x):[...a,{...item,quantity:1}]}),remove:(id:string)=>setItems(a=>a.filter(x=>x.productId!==id)),setQty:(id:string,q:number)=>setItems(a=>a.map(x=>x.productId===id?{...x,quantity:Math.max(1,Math.min(q,x.stock))}:x)),clear:()=>setItems([]),count:items.reduce((n,x)=>n+x.quantity,0),total:items.reduce((n,x)=>n+x.quantity*x.price,0)}),[items]);return <C.Provider value={value}>{children}</C.Provider>}
export function useCart(){const c=useContext(C);if(!c)throw new Error('CartProvider missing');return c}
export function CartButton(){const {count}=useCart();return <Link href="/cart" aria-label={`Panier, ${count} article${count>1?'s':''}`} className="relative rounded-full border border-[var(--border)] bg-white px-4 py-2.5 text-sm font-semibold">Panier{count>0&&<span className="ml-2 rounded-full bg-[var(--foreground)] px-2 py-0.5 text-xs text-white">{count}</span>}</Link>}
