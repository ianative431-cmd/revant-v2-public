"use client";
import { useEffect, useRef } from "react";
import { claimDelivery } from "@/app/driver/actions";

export default function DriverAutoClaim({ deliveryId }: { deliveryId: string }) {
  const sent = useRef(false);
  useEffect(() => {
    if (sent.current || !deliveryId) return;
    sent.current = true;
    const fd = new FormData();
    fd.set("deliveryId", deliveryId);
    void claimDelivery(fd);
  }, [deliveryId]);
  return <div className="revant-card p-6"><p className="font-semibold">Attribution de la livraison…</p><p className="mt-2 text-sm text-[var(--muted)]">Revant vérifie automatiquement si vous êtes le premier livreur à l’avoir ouverte.</p></div>;
}
