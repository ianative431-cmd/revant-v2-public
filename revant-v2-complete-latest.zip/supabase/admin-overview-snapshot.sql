create or replace function private.admin_overview_snapshot()
returns jsonb
language plpgsql
security definer
set search_path = public, private
as $$
declare result jsonb;
begin
  if auth.uid() is null or not public.has_any_admin_role() then
    raise exception 'forbidden';
  end if;

  select jsonb_build_object(
    'users', (select count(*) from public.profiles),
    'suspended_users', (select count(*) from public.profiles where is_suspended = true),
    'shops', (select count(*) from public.shops),
    'active_shops', (select count(*) from public.shops where status::text = 'active'),
    'products', (select count(*) from public.products),
    'pending_products', (select count(*) from public.products where status::text = 'pending'),
    'orders', (select count(*) from public.orders),
    'pending_orders', (select count(*) from public.orders where status::text in ('pending','confirmed','processing','ready_for_delivery','shipped')),
    'open_disputes', (select count(*) from public.disputes where status::text in ('open','under_review')),
    'pending_kyc', (select count(*) from public.kyc_profiles where status::text = 'pending'),
    'open_support', (select count(*) from public.support_tickets where status::text in ('open','in_progress')),
    'payments_enabled', coalesce((select enabled from public.payment_providers where enabled = true order by name limit 1), false),
    'recent_orders', coalesce((
      select jsonb_agg(to_jsonb(x) order by x.created_at desc)
      from (
        select id, order_number, status, total_amount, currency, created_at
        from public.orders order by created_at desc limit 8
      ) x
    ), '[]'::jsonb)
  ) into result;
  return result;
end;
$$;

revoke all on function private.admin_overview_snapshot() from public, anon, authenticated;
grant execute on function private.admin_overview_snapshot() to authenticated;

create or replace function public.admin_overview_snapshot()
returns jsonb
language sql
security invoker
set search_path = public, private
as $$ select private.admin_overview_snapshot(); $$;

revoke all on function public.admin_overview_snapshot() from public, anon;
grant execute on function public.admin_overview_snapshot() to authenticated;
