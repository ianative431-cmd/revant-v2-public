-- Revant V2 finance payout admin actions
-- Applied to Supabase project xugcmpnrigqfszyfufoc
create or replace function private.admin_update_payout(p_payout_id uuid, p_action text, p_reason text default null)
returns void language plpgsql security definer set search_path = public, private as $$
declare v_admin uuid := auth.uid(); v_payout payouts%rowtype; v_role_ok boolean;
begin
 if v_admin is null then raise exception 'not_authenticated'; end if;
 select exists(select 1 from user_roles where user_id=v_admin and role in ('super_admin','admin','finance_admin')) into v_role_ok;
 if not v_role_ok then raise exception 'not_authorized'; end if;
 if p_action not in ('approve','reject') then raise exception 'invalid_action'; end if;
 select * into v_payout from payouts where id=p_payout_id for update;
 if not found then raise exception 'payout_not_found'; end if;
 if v_payout.status <> 'pending' then raise exception 'payout_not_pending'; end if;
 if p_action='approve' then
   update payouts set status='approved', approved_at=now(), updated_at=now() where id=p_payout_id;
   insert into admin_actions(admin_id,action,target_type,target_id,reason,metadata) values(v_admin,'approve','payout',p_payout_id,p_reason,jsonb_build_object('previous_status','pending','new_status','approved'));
   insert into audit_logs(actor_id,action,entity_type,entity_id,description,metadata) values(v_admin,'approve','payout',p_payout_id,'Payout approuvé par un administrateur',jsonb_build_object('reason',p_reason));
 else
   update payouts set status='rejected', failure_reason=coalesce(p_reason,'Rejeté par un administrateur'), updated_at=now() where id=p_payout_id;
   insert into admin_actions(admin_id,action,target_type,target_id,reason,metadata) values(v_admin,'reject','payout',p_payout_id,p_reason,jsonb_build_object('previous_status','pending','new_status','rejected'));
   insert into audit_logs(actor_id,action,entity_type,entity_id,description,metadata) values(v_admin,'reject','payout',p_payout_id,'Payout rejeté par un administrateur',jsonb_build_object('reason',p_reason));
 end if;
end; $$;
revoke all on function private.admin_update_payout(uuid,text,text) from public;
revoke all on function private.admin_update_payout(uuid,text,text) from anon;
grant execute on function private.admin_update_payout(uuid,text,text) to authenticated;

create or replace function public.admin_update_payout(p_payout_id uuid, p_action text, p_reason text default null)
returns void language sql security invoker set search_path = public, private as $$
 select private.admin_update_payout(p_payout_id, p_action, p_reason);
$$;
revoke all on function public.admin_update_payout(uuid,text,text) from public;
revoke all on function public.admin_update_payout(uuid,text,text) from anon;
grant execute on function public.admin_update_payout(uuid,text,text) to authenticated;

-- Finance release integration added in the current V2 consolidation:
-- private.try_release_order_finance(uuid)
-- triggers on delivered orders and paid payments call the existing release RPC.
