-- Revant V2 — secure admin finance snapshot
-- Applied to Supabase project xugcmpnrigqfszyfufoc.
-- Private SECURITY DEFINER function is the only path that reads all finance rows for admins.
-- Public wrapper is SECURITY INVOKER and execution is restricted to authenticated users.

create or replace function private.admin_finance_snapshot()
returns jsonb
language plpgsql
security definer
set search_path = public, private
as $$
declare
  result jsonb;
begin
  if auth.uid() is null or not public.has_any_admin_role() then
    raise exception 'not authorized';
  end if;

  select jsonb_build_object(
    'summary', coalesce((select to_jsonb(s) from public.admin_finance_summary s limit 1), '{}'::jsonb),
    'rule', coalesce((select to_jsonb(r) from public.withdrawal_rules r where r.currency='XOF' and r.enabled limit 1), '{}'::jsonb),
    'providers', coalesce((select jsonb_agg(to_jsonb(p) order by p.name) from public.payment_providers p), '[]'::jsonb),
    'payments', coalesce((select jsonb_agg(to_jsonb(p) order by p.created_at desc) from (select id,order_id,amount,currency,status,provider,provider_reference,created_at,paid_at from public.payments order by created_at desc limit 20) p), '[]'::jsonb),
    'payouts', coalesce((select jsonb_agg(to_jsonb(p) order by p.requested_at desc) from (select id,seller_id,amount,currency,status,provider,destination_type,destination_reference,requested_at,failure_reason from public.payouts order by requested_at desc limit 30) p), '[]'::jsonb)
  ) into result;

  return result;
end;
$$;

revoke all on function private.admin_finance_snapshot() from public, anon, authenticated;
grant execute on function private.admin_finance_snapshot() to authenticated;

create or replace function public.admin_finance_snapshot()
returns jsonb
language sql
security invoker
set search_path = public, private
as $$ select private.admin_finance_snapshot(); $$;

revoke all on function public.admin_finance_snapshot() from public, anon;
grant execute on function public.admin_finance_snapshot() to authenticated;
