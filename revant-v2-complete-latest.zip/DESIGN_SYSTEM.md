# Revant V2 — Design direction

Revant uses a premium, warm marketplace language rather than a generic starter template.

The visual system combines soft neutral surfaces, terracotta accents, large rounded containers, subtle depth and restrained motion. Interactions should feel responsive without becoming distracting.

Motion principles:
- fade/slide entry for page content
- small lift on interactive cards
- subtle icon movement on hover
- no continuous animation on essential controls
- respect `prefers-reduced-motion` when motion-heavy components are added

Product principles:
- every visible icon must perform a real action
- mobile-first layouts
- clear hierarchy and generous spacing
- no fake marketplace data in production
- real Supabase data replaces placeholders as features are implemented
