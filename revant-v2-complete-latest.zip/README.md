# Revant V2

Nouvelle base frontend Revant, indépendante de l'ancien frontend et prête à utiliser le backend Supabase existant.

## Stack
- Next.js 16 App Router
- React 19
- TypeScript strict
- Tailwind CSS 4
- Supabase SSR

## Démarrage
1. Copier `.env.example` vers `.env.local`.
2. Renseigner l'URL Supabase et la clé anon.
3. `npm install`
4. `npm run dev`

Aucune clé service-role ne doit être placée dans le frontend.

## Livraison Revant — attribution instantanée

Le flux livraison inclut maintenant une demande diffusée aux livreurs actifs, une notification par appareil enregistré, une attribution atomique au premier livreur qui ouvre la demande, le suivi des statuts, et la confirmation de remise par code à quatre chiffres.

La base de données reste la source de vérité : même si deux livreurs ouvrent la notification presque simultanément, un seul peut obtenir la course.

Les notifications mobiles utilisent des tokens d’appareil enregistrés avec le provider `expo`. La fonction Supabase `dispatch-delivery-notifications` envoie la demande aux appareils actifs. L’application mobile doit enregistrer le token Expo du livreur dans `device_push_tokens`.

## Livraison Revant V2
- Espace livreur: `/driver`
- Détail d'une course: `/driver/[id]`
- Attribution atomique: `claim_delivery`
- Statuts livreur: assigned -> picked_up -> in_transit -> delivered
- Code de remise à 4 chiffres généré lors de la demande de livraison et envoyé au client via notification interne
- Notifications de demande diffusées aux livreurs actifs via `dispatch-delivery-notifications` (Expo pour l'application mobile)
- Suivi client: `/orders/[id]`
